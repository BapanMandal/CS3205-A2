# Part 1: MP3 Streaming over TCP

This is a TCP server program designed to stream and play MP3 music files to clients. It is compatible with a given TCP client application.
## Features
* Listens on a specified port for incoming connections.

* Streams MP3 music files from a specified directory to connected clients.

* Handles multiple client connections concurrently using multithreading.

* Provides a command-line interface for specifying port number, directory containing MP3 files, and maximum number of connections.

## Dependencies
- `ALSA library (alsa/asoundlib.h)`: for handling audio devices (not currently utilized).
- `argp.h`: for parsing command-line arguments.
- `arpa/inet.h`: for manipulating Internet addresses.
- `dirent.h`: for directory manipulation.
- `pthread.h`: for multithreading support.
- Standard C libraries: `stdio.h`, `stdlib.h`, `string.h`, `sys/socket.h`, `sys/stat.h`, `unistd.h`.

## Compilation
To compile the server program, use the following command:

```bash
gcc -o mp3_server mp3_server.c -lpthread -lasound
```

## Usage:
```
a.out [-?V] [-d DIR] [-n N] [-p PORT_NO] [--directory=DIR] [--connections=N] [--port=PORT_NO] [--help] [--usage] [--version]
```

* -p/--port PORT_NO: Specifies the port number on which the server should listen to. Default port is 8888.
* -d/--directory DIR: Specifies the directory containing the MP3 files.
* -n/--connections N: Specifies the maximum number of connections the server can handle.

## Example

./mp3_server -p 8888 -d /path/to/mp3/files -n 10
