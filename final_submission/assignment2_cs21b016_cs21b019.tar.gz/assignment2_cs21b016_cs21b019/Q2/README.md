# Part 2: Simple HTTP Server
This is a simple HTTP server implemented in C that serves static files (HTML, CSS, JavaScript, images) to clients over HTTP. The server listens on a specified port and serves files from a designated root directory.

## Features
* Supports HTTP GET requests.
* Serves static files such as HTML, CSS, JavaScript, images, etc.
* Basic error handling for file not found and unsupported HTTP methods.

## Usage
To run the server, you need to provide the port number and the root directory where your web files are located.

```
./http_server <PORT> <ROOT_DIR>
```

Replace PORT with the desired port number and ROOT_DIR with the path to the directory containing your web files.

## Supported MIME Types
The server identifies the MIME type of the requested file based on its extension and sends the appropriate Content-Type header in the HTTP response. 
Supported MIME types include:

- text/html for HTML files
- text/css for CSS files
- application/javascript for JavaScript files
- image/png for PNG images
- image/jpeg for JPEG/JPG images
- text/plain for other file types
## Error Handling
The server provides basic error handling for situations such as 
- file not found (404 Not Found) 
- unsupported HTTP methods (501 Not Implemented).

## Dependencies
This project depends on the following standard C libraries and headers:

- stdio.h
- stdlib.h
- string.h
- unistd.h
- sys/socket.h
- arpa/inet.h
- pthread.h