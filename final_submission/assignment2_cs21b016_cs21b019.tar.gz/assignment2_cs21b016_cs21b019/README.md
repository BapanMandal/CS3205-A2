# CS3205: Introduction to Computer Networks - Assignment 2

### 1. Bapan Mandal - CS21B016
### 2. Bhoge Aman   - CS21B019


## External References: 

### A Program Using Argp with User Options


For parsing and passing the command line arguements to the program verbatim, we have use the [argp library](https://www.gnu.org/software/libc/manual/html_node/Argp-Example-3.html).



