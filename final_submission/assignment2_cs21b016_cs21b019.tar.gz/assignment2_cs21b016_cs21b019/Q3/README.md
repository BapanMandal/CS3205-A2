# Part 3: Simple Chatroom Server
This is a simple chatroom server implemented in C that allows multiple clients to connect, chat with each other, and view the list of online users. The server has the ability to handle multiple clients concurrently and implements a timeout mechanism to disconnect inactive clients.

## Usage
To run the server, provide the following command-line arguments:
    
```bash
./chatroom_server <port> <max_clients> <timeout_seconds>
```
- `port`: The port number on which the server will listen for incoming connections.
- `max_clients`: The maximum number of clients that the server can handle concurrently.
- `timeout_seconds`: The duration of inactivity (in seconds) after which a client will be disconnected due to timeout.

## Features
- Multiple Clients: Supports multiple clients connecting to the server simultaneously.
- Chatroom Interaction: Clients can send messages to the chatroom, view the list of online users, and gracefully exit the chatroom.
- Username Management: Each client is assigned a unique username upon connection, and duplicate usernames are not allowed.
- Timeout Mechanism: Implements a timeout mechanism to disconnect clients who have been inactive for a specified duration.

## Protocol
- Clients connect to the server via TCP/IP sockets.
Upon connection, clients are prompted to enter their desired username.
- Clients can send messages to the chatroom by typing in the message prompt.

## Special commands:
- \list: Displays the list of users currently online.
- \bye: Disconnects the client from the chatroom.
The server broadcasts messages from one client to all other connected clients.

## Dependencies
This project depends on the following standard C libraries and headers:

- stdio.h
- stdlib.h
- string.h
- unistd.h
- stdbool.h
- pthread.h
- netinet/in.h
- time.h